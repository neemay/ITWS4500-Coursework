Yarden Ne'eman
Quiz 1
2/26/18

I used express for this lab as the server and installed the request and body-parser packages.

I was unable to get the server to return the result to the main page and add it to the list of other zip codes. Instead, the user can make multiple requests and it will display the result of that request one at a time.